﻿using ComputerStore.Shared.Business;
using ComputerStore.Shared.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ComputerStore.MVC.Controllers
{
    public class OrderController : Controller
    {
        // GET: Order
        public ActionResult Index()
        {
            OrderManager orderManager = new OrderManager();
            List<Order> orders = orderManager.ReadAllOrder();
            return View(orders);
        }

        public ActionResult Create()
        {

            return View();
        }

        public void SaveCreate(Order order)
        {
            OrderManager orderManager = new OrderManager();
            orderManager.Create(order);
        }


    }
}