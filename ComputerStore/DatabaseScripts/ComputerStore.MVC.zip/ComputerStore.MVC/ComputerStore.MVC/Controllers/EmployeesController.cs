﻿using ComputerStore.Shared.Business;
using ComputerStore.Shared.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ComputerStore.MVC.Controllers
{
    public class EmployeesController : Controller
    {
        // GET: Employees
        public ActionResult Index()
        {
            EmployeeManager employeeManager = new EmployeeManager();
            List<Employee> employees = employeeManager.GetAll();
            return View(employees);
        }

        public ActionResult Create()
        {
            return View();
        }

        public void Save(Employee employee)
        {
            EmployeeManager employeeManager = new EmployeeManager();
            employeeManager.Create(employee);
        }

        public void Delete(int id)
        {
            EmployeeManager employeeManager = new EmployeeManager();
            employeeManager.Delete(id);
        }

        public ActionResult Details(int id)
        {
            EmployeeManager employeeManager = new EmployeeManager();
            Employee employee = employeeManager.Details(id);
            return View(employee);
        }

        public ActionResult Edit(int id)
        {
            EmployeeManager employeeManager = new EmployeeManager();
            Employee employee = employeeManager.Details(id);

            var titles = GetAllTitles();
            ViewBag.AllTitles = titles;

            return View(employee);
        }

        private List<Title> GetAllTitles()
        {
            //var t1 = new Title { Id = 1, TitleName = "Kajo" };
            //var t2 = new Title { Id = 2, TitleName = "IkO" };
            //var titles = new List<Title> { t1, t2 };
            // return titles;

            TitleManager titleManager = new TitleManager();
            List<Title> titles = titleManager.GetAllTitle();
            return titles;
        }

        public void SaveEdit(Employee employee)
        {
            EmployeeManager employeeManager = new EmployeeManager();
            employeeManager.Edit(employee);
        }
    }

    
}