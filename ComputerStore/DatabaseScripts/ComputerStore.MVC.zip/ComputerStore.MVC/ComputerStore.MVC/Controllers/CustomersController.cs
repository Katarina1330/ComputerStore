﻿using ComputerStore.Shared.Business;
using ComputerStore.Shared.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ComputerStore.MVC.Controllers
{
    public class CustomersController : Controller
    {
        // GET: Customers
        public ActionResult Index()
        {
            CustomerManager customerManager = new CustomerManager();
            List<Customer> customers = customerManager.getAll();
            return View(customers);
        }

        public ActionResult Create()
        {
            return View();
        }

        public void SaveCreate(Customer customer)
        {
            CustomerManager customerManager = new CustomerManager();
            customerManager.Create(customer);
        }

        public void Delete(int id)
        {
            CustomerManager customerManager = new CustomerManager();
            customerManager.Delete(id);
        }

        public ActionResult Details(int id)
        {
            CustomerManager customerManager = new CustomerManager();
            Customer customer =  customerManager.Details(id);
            return View(customer);
        }

        public ActionResult Edit(int id)
        {
            CustomerManager customerManager = new CustomerManager();
            Customer customer = customerManager.Details(id);
            return View(customer);
        }

        public void SaveEdit(Customer customer)
        {
            CustomerManager customerManager = new CustomerManager();
            customerManager.Edit(customer);
        }
    }
}