﻿using ComputerStore.Shared.Business;
using ComputerStore.Shared.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ComputerStore.MVC.Controllers
{
    public class ProductController : Controller
    {
        // GET: Product
        public ActionResult Index()
        {
            ProductManager productManager = new ProductManager();
            List<Product> products = productManager.GetAll();
            return View(products);
        }

        public ActionResult Create()
        {
            return View();
        }

        public void Save(Product product)
        {

            ProductManager productManager = new ProductManager();
            productManager.Create(product);
        }

        public void Delete(int id)
        {
            ProductManager productManager = new ProductManager();
            productManager.Delete(id);
        }

        public ActionResult Details(int id)
        {
            ProductManager productManager = new ProductManager();
            Product product = productManager.Details(id);
            return View(product);
        }

        public ActionResult Edit(int id)
        {
            ProductManager productManager = new ProductManager();
            Product product = productManager.Details(id);
            return View(product);
        }

        public void SaveEdit(Product product)
        {
            ProductManager productManager = new ProductManager();
            productManager.Edit(product);
        }

       
    }
}