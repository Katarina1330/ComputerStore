namespace ComputerStore.Shared.Models
{
    using System;
    using System.Data.Entity;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Linq;

    public partial class ComputerStoreMVC : DbContext
    {
        public ComputerStoreMVC()
            : base("name=ComputerStoreMVC")
        {
        }

        public virtual DbSet<Customer> Customers { get; set; }
        public virtual DbSet<Employee> Employees { get; set; }
        public virtual DbSet<Order> Orders { get; set; }
        public virtual DbSet<Product> Products { get; set; }
        public virtual DbSet<Title> Titles { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Customer>()
                .HasMany(e => e.Orders)
                .WithRequired(e => e.Customer)
                .HasForeignKey(e => e.IdCustomer)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Employee>()
                .HasMany(e => e.Orders)
                .WithRequired(e => e.Employee)
                .HasForeignKey(e => e.IdEmployee);

            modelBuilder.Entity<Order>()
                .Property(e => e.PriceOrder)
                .HasPrecision(19, 4);

            modelBuilder.Entity<Order>()
                .HasMany(e => e.Products)
                .WithMany(e => e.Orders)
                .Map(m => m.ToTable("OrderProduct").MapLeftKey("IdOrder").MapRightKey("IdProduct"));

            modelBuilder.Entity<Product>()
                .Property(e => e.PriceProduct)
                .HasPrecision(19, 4);

            modelBuilder.Entity<Product>()
                .Property(e => e.MadeIn)
                .IsFixedLength();

            modelBuilder.Entity<Title>()
                .HasMany(e => e.Employees)
                .WithOptional(e => e.Title)
                .HasForeignKey(e => e.IdTitle);
        }
    }
}
