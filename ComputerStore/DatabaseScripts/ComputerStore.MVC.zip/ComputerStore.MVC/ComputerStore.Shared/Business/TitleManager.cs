﻿using ComputerStore.Shared.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComputerStore.Shared.Business
{
    public class TitleManager
    {
        public List<Title> GetAllTitle()
        {
            ComputerStoreMVC context = new ComputerStoreMVC();
            return context.Titles.ToList();
        }
    }
}
