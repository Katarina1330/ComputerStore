﻿using ComputerStore.Shared.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComputerStore.Shared.Business
{
    public class CustomerManager
    {
        public void Create(Customer customer)
        {
            ComputerStoreMVC context = new ComputerStoreMVC();
            context.Customers.Add(customer);
            context.SaveChanges();
        }

        public List<Customer> getAll()
        {
            ComputerStoreMVC context = new ComputerStoreMVC();
            return context.Customers.ToList();
        }

        public void Delete(int idCustomer)
        {
            ComputerStoreMVC context = new ComputerStoreMVC();
            Customer customer = context.Customers.Where(p => p.Id == idCustomer).Single();
            context.Customers.Remove(customer);
            context.SaveChanges();
        }

        public Customer Details(int id)
        {
            ComputerStoreMVC context = new ComputerStoreMVC();
            Customer customer = context.Customers.Where(p => p.Id == id).ToList().Single();
            return customer;
        }

        public void Edit(Customer customer)
        {
            ComputerStoreMVC context = new ComputerStoreMVC();
            context.Entry(customer).State = EntityState.Modified;

            context.SaveChanges();
        }

    }
}
