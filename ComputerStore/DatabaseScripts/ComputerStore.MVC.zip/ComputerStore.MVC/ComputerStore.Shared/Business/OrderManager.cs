﻿using ComputerStore.Shared.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComputerStore.Shared.Business
{
    public class OrderManager
    {
        public List<Order> ReadAllOrder()
        {
            ComputerStoreMVC context = new ComputerStoreMVC();
            List<Order> orders = context.Orders.ToList();
            return orders;
        }

        public void Create(Order order)
        {
            ComputerStoreMVC context = new ComputerStoreMVC();
            context.Orders.Add(order);
            context.SaveChanges();
        }

    }
}
