﻿using ComputerStore.Shared.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComputerStore.Shared.Business
{
    public class ProductManager
    {
        public void Create(Product product)
        {
            ComputerStoreMVC context = new ComputerStoreMVC();
            context.Products.Add(product);
            context.SaveChanges();
        }

        public List<Product> GetAll()
        {
            ComputerStoreMVC context = new ComputerStoreMVC();
            return context.Products.ToList();
        }

        public void Delete(int id)
        {
            ComputerStoreMVC context = new ComputerStoreMVC();
            Product product = context.Products.Where(p => p.Id == id).Single();
            context.Products.Remove(product);
            context.SaveChanges();
        }

        public Product Details(int id)
        {
            ComputerStoreMVC context = new ComputerStoreMVC();
            Product product = context.Products.Where(p => p.Id == id).Single();
            return product;
        }

        public void Edit(Product product)
        {
            ComputerStoreMVC context = new ComputerStoreMVC();
            context.Entry(product).State = EntityState.Modified;
            context.SaveChanges();
        }
    }
}
