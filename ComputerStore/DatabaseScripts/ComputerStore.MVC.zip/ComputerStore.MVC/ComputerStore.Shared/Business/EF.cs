﻿using ComputerStore.Shared.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComputerStore.Shared.Business
{
    public class EF
    {
        public void Create()
        {
            Employee employee = new Employee
            {
                FirstName = "Ika",
                LastName = "Ikic",
                CellPhone = "650-333-333",
                Address = "Allma ave"
            };

            var id = employee.Id;
            ComputerStoreMVC context = new ComputerStoreMVC();
            context.Employees.Add(employee);
            context.SaveChanges();
            var id2 = employee.Id;
        }

        public void Delete1()
        {
            Employee employee = new Employee
            {
                Id = 13
            };

            ComputerStoreMVC context = new ComputerStoreMVC();
            context.Entry(employee).State = System.Data.Entity.EntityState.Deleted;
            context.SaveChanges();
        }

        public void Delete2(int id)
        {

            ComputerStoreMVC context = new ComputerStoreMVC();

            Employee employee = context.Employees.Where(p => p.Id == id).Single();
            context.Employees.Remove(employee);
            context.SaveChanges();
        }

        public void Read()
        {
            ComputerStoreMVC context = new ComputerStoreMVC();
            var e = context.Employees.Where(p => p.Id == 9).ToList().Where(m => m.Id ==5);

            
        }
    }
}
