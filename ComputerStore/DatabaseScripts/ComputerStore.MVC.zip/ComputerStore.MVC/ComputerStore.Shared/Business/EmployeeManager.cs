﻿using ComputerStore.Shared.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComputerStore.Shared.Business
{
    public class EmployeeManager
    {
        public void Create(Employee employee)
        {
            ComputerStoreMVC context = new ComputerStoreMVC();
            context.Employees.Add(employee);
            context.SaveChanges(); 
        }

        public List<Employee> GetAll()
        {
            ComputerStoreMVC context = new ComputerStoreMVC();
            return context.Employees.ToList();
        }

        public void Delete(int id)
        {
            //foreach (var e in context.Employees)
            //{
            //    if (e.Id == id)
            //    {

            //    }
            //}
            ComputerStoreMVC context = new ComputerStoreMVC();
            Employee employee = context.Employees.Where(p => p.Id == id).Single();
            context.Employees.Remove(employee);
            context.SaveChanges();
        }

        public Employee Details(int id)
        {
            ComputerStoreMVC context = new ComputerStoreMVC();
            Employee employee = context.Employees.Where(p => p.Id == id).Single();
            return employee;
        }

        public void Edit(Employee employee)
        {
            ComputerStoreMVC context = new ComputerStoreMVC();
            context.Entry(employee).State = EntityState.Modified;
            context.SaveChanges();
        }
    }
}
