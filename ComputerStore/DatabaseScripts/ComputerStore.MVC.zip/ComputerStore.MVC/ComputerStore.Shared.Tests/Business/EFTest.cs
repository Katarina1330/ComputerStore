﻿using ComputerStore.Shared.Business;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComputerStore.Shared.Tests.Business
{
    [TestClass]
    public class EFTest
    {
        [TestMethod]
        public void Create()
        {
            EF ef = new EF();
            ef.Create();
        }

        [TestMethod]
        public void Delete()
        {
            EF ef = new EF();
            ef.Delete2(15);
        }

        [TestMethod]
        public void Read()
        {
            EF ef = new EF();
            ef.Read();
        }
    }
}
